#include "AmbienceSensor.h"


using namespace std;

int main() {
	AmbienceSensor light;
	while (true) 
	{

		string data = light.getData();
		cout << data << endl;
	}

	return 0;
}

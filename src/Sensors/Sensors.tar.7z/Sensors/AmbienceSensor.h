#include "mcp3008Spi.h"
#include <math.h>

class AmbienceSensor {
	public:
		AmbienceSensor();	
		std::string getData();
		
	
				
};
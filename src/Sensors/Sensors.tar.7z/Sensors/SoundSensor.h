#include "mcp3008Spi.h"
#include <math.h>

class SoundSensor {
	public:
		SoundSensor();	
		std::string getData();
		
	
				
};
#include "mcp3008Spi.h"
#include <math.h>

class HumiditySensor {
	public:
		HumiditySensor();	
		std::string getData();
		
	
				
};